import { defineStore as J } from "pinia";
import { ref as h, computed as E, defineComponent as I, createElementBlock as u, openBlock as n, createElementVNode as e, createCommentVNode as k, normalizeClass as M, toDisplayString as c, normalizeStyle as _, onMounted as H, withModifiers as P, withDirectives as w, createTextVNode as K, vModelText as N, Fragment as $, renderList as T, vModelSelect as S, watch as X, createStaticVNode as R, vModelCheckbox as Y, createBlock as j, unref as x } from "vue";
import O from "axios";
const G = J("tasks", () => {
  const p = h([]), l = h([]), d = h(!1), y = h(null), g = h("all"), f = h("all"), r = h("all"), t = h(""), o = E(() => {
    let i = p.value.filter((b) => !b.isArchived);
    if (g.value !== "all" && (i = i.filter((b) => b.status === g.value)), f.value !== "all" && (i = i.filter((b) => b.priority === f.value)), r.value !== "all" && (i = i.filter((b) => b.categoryId === r.value)), t.value) {
      const b = t.value.toLowerCase();
      i = i.filter(
        (C) => C.title.toLowerCase().includes(b) || C.description?.toLowerCase().includes(b)
      );
    }
    return i;
  }), s = E(() => ({
    TODO: p.value.filter((i) => i.status === "TODO" && !i.isArchived),
    IN_PROGRESS: p.value.filter((i) => i.status === "IN_PROGRESS" && !i.isArchived),
    IN_REVIEW: p.value.filter((i) => i.status === "IN_REVIEW" && !i.isArchived),
    DONE: p.value.filter((i) => i.status === "DONE" && !i.isArchived)
  }));
  async function m() {
    d.value = !0, y.value = null;
    try {
      const i = await O.get("/api/plugin-api/task-manager/tasks");
      p.value = i.data;
    } catch (i) {
      y.value = i.response?.data?.message || "Failed to fetch tasks", console.error("Error fetching tasks:", i);
    } finally {
      d.value = !1;
    }
  }
  async function A() {
    try {
      const i = await O.get("/api/plugin-api/task-manager/categories");
      l.value = i.data;
    } catch (i) {
      console.error("Error fetching categories:", i);
    }
  }
  async function B(i) {
    d.value = !0, y.value = null;
    try {
      const b = await O.post("/api/plugin-api/task-manager/tasks", i);
      return p.value.push(b.data), { success: !0, task: b.data };
    } catch (b) {
      return y.value = b.response?.data?.message || "Failed to create task", { success: !1, error: y.value };
    } finally {
      d.value = !1;
    }
  }
  async function F(i, b) {
    d.value = !0, y.value = null;
    try {
      const C = await O.patch(`/api/plugin-api/task-manager/tasks/${i}`, b), V = p.value.findIndex((q) => q.id === i);
      return V !== -1 && (p.value[V] = C.data), { success: !0, task: C.data };
    } catch (C) {
      return y.value = C.response?.data?.message || "Failed to update task", { success: !1, error: y.value };
    } finally {
      d.value = !1;
    }
  }
  async function U(i) {
    d.value = !0, y.value = null;
    try {
      return await O.delete(`/api/plugin-api/task-manager/tasks/${i}`), p.value = p.value.filter((b) => b.id !== i), { success: !0 };
    } catch (b) {
      return y.value = b.response?.data?.message || "Failed to delete task", { success: !1, error: y.value };
    } finally {
      d.value = !1;
    }
  }
  async function L(i, b) {
    const C = b ? "DONE" : "TODO", V = b ? (/* @__PURE__ */ new Date()).toISOString() : null;
    return F(i, { status: C, completedAt: V });
  }
  function D(i) {
    g.value = i;
  }
  function a(i) {
    f.value = i;
  }
  function v(i) {
    r.value = i;
  }
  function z(i) {
    t.value = i;
  }
  function Q() {
    g.value = "all", f.value = "all", r.value = "all", t.value = "";
  }
  return {
    // State
    tasks: p,
    categories: l,
    loading: d,
    error: y,
    statusFilter: g,
    priorityFilter: f,
    categoryFilter: r,
    searchQuery: t,
    // Computed
    filteredTasks: o,
    tasksByStatus: s,
    // Actions
    fetchTasks: m,
    fetchCategories: A,
    createTask: B,
    updateTask: F,
    deleteTask: U,
    toggleTaskStatus: L,
    setStatusFilter: D,
    setPriorityFilter: a,
    setCategoryFilter: v,
    setSearchQuery: z,
    clearFilters: Q
  };
}), Z = { class: "border-b border-gray-700 hover:bg-gray-800/50 transition-colors" }, ee = { class: "px-4 py-3" }, te = ["checked"], se = { class: "px-4 py-3" }, oe = {
  key: 0,
  class: "text-sm text-gray-400 mt-1 line-clamp-1"
}, re = { class: "px-4 py-3" }, ae = { class: "px-4 py-3" }, le = { class: "px-4 py-3" }, ne = { class: "px-4 py-3 text-sm text-gray-400" }, ie = { class: "px-4 py-3" }, ue = { class: "flex items-center space-x-2" }, de = /* @__PURE__ */ I({
  __name: "TaskCard",
  props: {
    task: {}
  },
  emits: ["toggle", "edit", "delete"],
  setup(p) {
    const l = p, d = E(() => {
      const r = {
        LOW: "bg-blue-500/20 text-blue-400",
        MEDIUM: "bg-yellow-500/20 text-yellow-400",
        HIGH: "bg-orange-500/20 text-orange-400",
        URGENT: "bg-red-500/20 text-red-400"
      };
      return r[l.task.priority] || r.MEDIUM;
    }), y = E(() => {
      const r = {
        TODO: "bg-gray-500/20 text-gray-400",
        IN_PROGRESS: "bg-blue-500/20 text-blue-400",
        IN_REVIEW: "bg-purple-500/20 text-purple-400",
        DONE: "bg-green-500/20 text-green-400",
        CANCELLED: "bg-red-500/20 text-red-400"
      };
      return r[l.task.status] || r.TODO;
    }), g = (r) => r.replace("_", " "), f = (r) => {
      const t = new Date(r), o = /* @__PURE__ */ new Date(), s = new Date(o);
      return s.setDate(s.getDate() + 1), t.toDateString() === o.toDateString() ? "Today" : t.toDateString() === s.toDateString() ? "Tomorrow" : t.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    };
    return (r, t) => (n(), u("tr", Z, [
      e("td", ee, [
        e("input", {
          type: "checkbox",
          checked: p.task.status === "DONE",
          onChange: t[0] || (t[0] = (o) => r.$emit("toggle", p.task.id)),
          class: "w-4 h-4 rounded border-gray-600 text-primary-600 focus:ring-primary-500 focus:ring-offset-gray-900"
        }, null, 40, te)
      ]),
      e("td", se, [
        e("div", null, [
          e("p", {
            class: M(["font-medium", p.task.status === "DONE" ? "line-through text-gray-500" : "text-white"])
          }, c(p.task.title), 3),
          p.task.description ? (n(), u("p", oe, c(p.task.description), 1)) : k("", !0)
        ])
      ]),
      e("td", re, [
        p.task.categoryName ? (n(), u("span", {
          key: 0,
          class: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
          style: _({
            backgroundColor: p.task.categoryColor + "20",
            color: p.task.categoryColor
          })
        }, c(p.task.categoryName), 5)) : k("", !0)
      ]),
      e("td", ae, [
        e("span", {
          class: M(["inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium", d.value])
        }, c(p.task.priority), 3)
      ]),
      e("td", le, [
        e("span", {
          class: M(["inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium", y.value])
        }, c(g(p.task.status)), 3)
      ]),
      e("td", ne, c(p.task.dueDate ? f(p.task.dueDate) : "-"), 1),
      e("td", ie, [
        e("div", ue, [
          e("button", {
            onClick: t[1] || (t[1] = (o) => r.$emit("edit", p.task)),
            class: "p-1.5 text-gray-400 hover:text-primary-400 hover:bg-gray-700 rounded transition-colors",
            title: "Edit"
          }, [...t[3] || (t[3] = [
            e("svg", {
              class: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24"
            }, [
              e("path", {
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
              })
            ], -1)
          ])]),
          e("button", {
            onClick: t[2] || (t[2] = (o) => r.$emit("delete", p.task.id)),
            class: "p-1.5 text-gray-400 hover:text-red-400 hover:bg-gray-700 rounded transition-colors",
            title: "Delete"
          }, [...t[4] || (t[4] = [
            e("svg", {
              class: "w-4 h-4",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24"
            }, [
              e("path", {
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
              })
            ], -1)
          ])])
        ])
      ])
    ]));
  }
}), ce = { class: "bg-gray-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" }, pe = { class: "flex items-center justify-between p-6 border-b border-gray-700" }, ge = { class: "text-xl font-bold text-white" }, ye = { class: "grid grid-cols-2 gap-4" }, me = ["value"], xe = { class: "grid grid-cols-2 gap-4" }, ve = { class: "flex justify-end space-x-3 pt-4" }, fe = ["disabled"], W = /* @__PURE__ */ I({
  __name: "TaskForm",
  props: {
    task: {},
    categories: {}
  },
  emits: ["close", "submit"],
  setup(p, { emit: l }) {
    const d = p, y = l, g = h(!1), f = E(() => !!d.task), r = h({
      title: "",
      description: "",
      status: "TODO",
      priority: "MEDIUM",
      categoryId: "",
      dueDate: "",
      estimatedHours: 0
    });
    H(() => {
      d.task && (r.value = {
        title: d.task.title,
        description: d.task.description || "",
        status: d.task.status,
        priority: d.task.priority,
        categoryId: d.task.categoryId || "",
        dueDate: d.task.dueDate ? d.task.dueDate.split("T")[0] : "",
        estimatedHours: d.task.estimatedHours
      });
    });
    const t = () => {
      g.value = !0;
      const o = {
        title: r.value.title,
        description: r.value.description || void 0,
        status: r.value.status,
        priority: r.value.priority,
        categoryId: r.value.categoryId || void 0,
        dueDate: r.value.dueDate || void 0,
        estimatedHours: r.value.estimatedHours
      };
      y("submit", o);
    };
    return (o, s) => (n(), u("div", {
      class: "fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4",
      onClick: s[9] || (s[9] = P((m) => o.$emit("close"), ["self"]))
    }, [
      e("div", ce, [
        e("div", pe, [
          e("h3", ge, c(f.value ? "Edit Task" : "New Task"), 1),
          e("button", {
            onClick: s[0] || (s[0] = (m) => o.$emit("close")),
            class: "text-gray-400 hover:text-white"
          }, [...s[10] || (s[10] = [
            e("svg", {
              class: "w-6 h-6",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24"
            }, [
              e("path", {
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M6 18L18 6M6 6l12 12"
              })
            ], -1)
          ])])
        ]),
        e("form", {
          onSubmit: P(t, ["prevent"]),
          class: "p-6 space-y-4"
        }, [
          e("div", null, [
            s[11] || (s[11] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, [
              K(" Title "),
              e("span", { class: "text-red-400" }, "*")
            ], -1)),
            w(e("input", {
              "onUpdate:modelValue": s[1] || (s[1] = (m) => r.value.title = m),
              type: "text",
              required: "",
              class: "w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent",
              placeholder: "Enter task title..."
            }, null, 512), [
              [N, r.value.title]
            ])
          ]),
          e("div", null, [
            s[12] || (s[12] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Description ", -1)),
            w(e("textarea", {
              "onUpdate:modelValue": s[2] || (s[2] = (m) => r.value.description = m),
              rows: "3",
              class: "w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none",
              placeholder: "Add a description..."
            }, null, 512), [
              [N, r.value.description]
            ])
          ]),
          e("div", ye, [
            e("div", null, [
              s[14] || (s[14] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Category ", -1)),
              w(e("select", {
                "onUpdate:modelValue": s[3] || (s[3] = (m) => r.value.categoryId = m),
                class: "w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              }, [
                s[13] || (s[13] = e("option", { value: "" }, "No category", -1)),
                (n(!0), u($, null, T(p.categories, (m) => (n(), u("option", {
                  key: m.id,
                  value: m.id
                }, c(m.name), 9, me))), 128))
              ], 512), [
                [S, r.value.categoryId]
              ])
            ]),
            e("div", null, [
              s[16] || (s[16] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Priority ", -1)),
              w(e("select", {
                "onUpdate:modelValue": s[4] || (s[4] = (m) => r.value.priority = m),
                class: "w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              }, [...s[15] || (s[15] = [
                e("option", { value: "LOW" }, "Low", -1),
                e("option", { value: "MEDIUM" }, "Medium", -1),
                e("option", { value: "HIGH" }, "High", -1),
                e("option", { value: "URGENT" }, "Urgent", -1)
              ])], 512), [
                [S, r.value.priority]
              ])
            ])
          ]),
          e("div", xe, [
            e("div", null, [
              s[18] || (s[18] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Status ", -1)),
              w(e("select", {
                "onUpdate:modelValue": s[5] || (s[5] = (m) => r.value.status = m),
                class: "w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              }, [...s[17] || (s[17] = [
                e("option", { value: "TODO" }, "To Do", -1),
                e("option", { value: "IN_PROGRESS" }, "In Progress", -1),
                e("option", { value: "IN_REVIEW" }, "In Review", -1),
                e("option", { value: "DONE" }, "Done", -1)
              ])], 512), [
                [S, r.value.status]
              ])
            ]),
            e("div", null, [
              s[19] || (s[19] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Due Date ", -1)),
              w(e("input", {
                "onUpdate:modelValue": s[6] || (s[6] = (m) => r.value.dueDate = m),
                type: "date",
                class: "w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              }, null, 512), [
                [N, r.value.dueDate]
              ])
            ])
          ]),
          e("div", null, [
            s[20] || (s[20] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Estimated Hours ", -1)),
            w(e("input", {
              "onUpdate:modelValue": s[7] || (s[7] = (m) => r.value.estimatedHours = m),
              type: "number",
              min: "0",
              step: "0.5",
              class: "w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
            }, null, 512), [
              [
                N,
                r.value.estimatedHours,
                void 0,
                { number: !0 }
              ]
            ])
          ]),
          e("div", ve, [
            e("button", {
              type: "button",
              onClick: s[8] || (s[8] = (m) => o.$emit("close")),
              class: "px-6 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors"
            }, " Cancel "),
            e("button", {
              type: "submit",
              disabled: g.value,
              class: "px-6 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            }, c(g.value ? "Saving..." : f.value ? "Update Task" : "Create Task"), 9, fe)
          ])
        ], 32)
      ])
    ]));
  }
}), be = { class: "bg-gray-800 border border-gray-700 rounded-lg p-4 space-y-4" }, ke = ["value"], he = { class: "flex items-center" }, Qt = /* @__PURE__ */ I({
  __name: "TaskFilters",
  props: {
    categories: {},
    modelValue: {}
  },
  emits: ["update:modelValue", "apply"],
  setup(p, { emit: l }) {
    const d = p, y = l, g = h({
      search: "",
      status: "",
      priority: "",
      categoryId: "",
      isArchived: !1
    });
    X(() => d.modelValue, (t) => {
      t && (g.value = { ...t });
    }, { immediate: !0 });
    const f = () => {
      const t = Object.fromEntries(
        Object.entries(g.value).filter(([o, s]) => s !== "" && s !== !1)
      );
      y("update:modelValue", t), y("apply", t);
    }, r = () => {
      g.value = {
        search: "",
        status: "",
        priority: "",
        categoryId: "",
        isArchived: !1
      }, f();
    };
    return (t, o) => (n(), u("div", be, [
      o[13] || (o[13] = e("h3", { class: "text-white font-semibold mb-4" }, "Filters", -1)),
      e("div", null, [
        o[5] || (o[5] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Search ", -1)),
        w(e("input", {
          "onUpdate:modelValue": o[0] || (o[0] = (s) => g.value.search = s),
          type: "text",
          class: "w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:outline-none focus:border-primary-500",
          placeholder: "Search tasks..."
        }, null, 512), [
          [N, g.value.search]
        ])
      ]),
      e("div", null, [
        o[7] || (o[7] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Status ", -1)),
        w(e("select", {
          "onUpdate:modelValue": o[1] || (o[1] = (s) => g.value.status = s),
          class: "w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:outline-none focus:border-primary-500"
        }, [...o[6] || (o[6] = [
          R('<option value="">All Statuses</option><option value="TODO">To Do</option><option value="IN_PROGRESS">In Progress</option><option value="IN_REVIEW">In Review</option><option value="DONE">Done</option><option value="CANCELLED">Cancelled</option>', 6)
        ])], 512), [
          [S, g.value.status]
        ])
      ]),
      e("div", null, [
        o[9] || (o[9] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Priority ", -1)),
        w(e("select", {
          "onUpdate:modelValue": o[2] || (o[2] = (s) => g.value.priority = s),
          class: "w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:outline-none focus:border-primary-500"
        }, [...o[8] || (o[8] = [
          R('<option value="">All Priorities</option><option value="URGENT">Urgent</option><option value="HIGH">High</option><option value="MEDIUM">Medium</option><option value="LOW">Low</option>', 5)
        ])], 512), [
          [S, g.value.priority]
        ])
      ]),
      e("div", null, [
        o[11] || (o[11] = e("label", { class: "block text-sm font-medium text-gray-300 mb-2" }, " Category ", -1)),
        w(e("select", {
          "onUpdate:modelValue": o[3] || (o[3] = (s) => g.value.categoryId = s),
          class: "w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:outline-none focus:border-primary-500"
        }, [
          o[10] || (o[10] = e("option", { value: "" }, "All Categories", -1)),
          (n(!0), u($, null, T(p.categories, (s) => (n(), u("option", {
            key: s.id,
            value: s.id
          }, c(s.icon) + " " + c(s.name), 9, ke))), 128))
        ], 512), [
          [S, g.value.categoryId]
        ])
      ]),
      e("div", he, [
        w(e("input", {
          "onUpdate:modelValue": o[4] || (o[4] = (s) => g.value.isArchived = s),
          type: "checkbox",
          id: "archived",
          class: "w-4 h-4 text-primary-600 bg-gray-700 border-gray-600 rounded focus:ring-primary-500"
        }, null, 512), [
          [Y, g.value.isArchived]
        ]),
        o[12] || (o[12] = e("label", {
          for: "archived",
          class: "ml-2 text-sm text-gray-300"
        }, " Show Archived ", -1))
      ]),
      e("div", { class: "flex space-x-2 pt-4" }, [
        e("button", {
          onClick: f,
          class: "flex-1 px-4 py-2 bg-primary-600 text-white rounded-lg text-sm hover:bg-primary-700 transition-colors"
        }, " Apply "),
        e("button", {
          onClick: r,
          class: "px-4 py-2 bg-gray-700 text-white rounded-lg text-sm hover:bg-gray-600 transition-colors"
        }, " Reset ")
      ])
    ]));
  }
}), we = { class: "space-y-6" }, De = { class: "flex items-center justify-between" }, $e = { class: "flex items-center space-x-4" }, Te = { class: "px-3 py-1 bg-gray-700 rounded-full text-sm text-gray-300" }, Ce = { class: "card" }, Se = { class: "flex flex-wrap items-center gap-4" }, Ee = { class: "flex items-center space-x-2" }, Ne = { class: "flex space-x-1" }, Ie = ["onClick"], Oe = { class: "flex items-center space-x-2" }, _e = ["value"], Me = { class: "flex items-center space-x-2" }, Fe = { class: "flex-1 min-w-[200px]" }, Ue = {
  key: 0,
  class: "card text-center py-12"
}, Ve = {
  key: 1,
  class: "card bg-red-500/10 border border-red-500/20"
}, Re = { class: "flex items-center space-x-3" }, je = { class: "text-red-400" }, He = {
  key: 2,
  class: "card overflow-hidden"
}, Ae = { class: "overflow-x-auto" }, Be = { class: "w-full" }, Le = { class: "bg-gray-800 border-b border-gray-700" }, Pe = { class: "px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider w-12" }, Ge = {
  key: 3,
  class: "card text-center py-12"
}, We = { class: "text-gray-400 mb-6" }, ze = { class: "bg-gray-800 rounded-xl p-6 max-w-md w-full" }, Qe = { class: "flex justify-end space-x-3" }, qt = /* @__PURE__ */ I({
  __name: "TaskList",
  setup(p) {
    const l = G(), d = h(!1), y = h(), g = h(!1), f = h(null), r = [
      { label: "All", value: "all" },
      { label: "To Do", value: "TODO" },
      { label: "In Progress", value: "IN_PROGRESS" },
      { label: "Done", value: "DONE" }
    ], t = E(() => l.filteredTasks), o = E(() => l.statusFilter !== "all" || l.priorityFilter !== "all" || l.categoryFilter !== "all" || l.searchQuery !== ""), s = async (D) => {
      const a = l.tasks.find((v) => v.id === D);
      a && await l.toggleTaskStatus(D, a.status !== "DONE");
    }, m = (D) => {
      y.value = D, d.value = !0;
    }, A = (D) => {
      f.value = D, g.value = !0;
    }, B = async () => {
      f.value && (await l.deleteTask(f.value), g.value = !1, f.value = null);
    }, F = async (D) => {
      y.value ? await l.updateTask(y.value.id, D) : await l.createTask(D), U();
    }, U = () => {
      d.value = !1, y.value = void 0;
    }, L = (D) => {
      const a = D.target.checked;
      console.log("Toggle all:", a);
    };
    return H(async () => {
      await l.fetchCategories(), await l.fetchTasks();
    }), (D, a) => (n(), u("div", we, [
      e("div", De, [
        e("div", $e, [
          a[8] || (a[8] = e("h3", { class: "text-2xl font-bold text-white" }, "Tasks", -1)),
          e("span", Te, c(t.value.length) + " tasks ", 1)
        ]),
        e("button", {
          onClick: a[0] || (a[0] = (v) => d.value = !0),
          class: "flex items-center space-x-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-medium transition-colors"
        }, [...a[9] || (a[9] = [
          e("svg", {
            class: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            e("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M12 4v16m8-8H4"
            })
          ], -1),
          e("span", null, "New Task", -1)
        ])])
      ]),
      e("div", Ce, [
        e("div", Se, [
          e("div", Ee, [
            a[10] || (a[10] = e("span", { class: "text-sm text-gray-400" }, "Status:", -1)),
            e("div", Ne, [
              (n(), u($, null, T(r, (v) => e("button", {
                key: v.value,
                onClick: (z) => x(l).setStatusFilter(v.value),
                class: M(["px-3 py-1.5 rounded-lg text-sm font-medium transition-colors", x(l).statusFilter === v.value ? "bg-primary-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"])
              }, c(v.label), 11, Ie)), 64))
            ])
          ]),
          e("div", Oe, [
            a[12] || (a[12] = e("span", { class: "text-sm text-gray-400" }, "Category:", -1)),
            w(e("select", {
              "onUpdate:modelValue": a[1] || (a[1] = (v) => x(l).categoryFilter = v),
              class: "px-3 py-1.5 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
            }, [
              a[11] || (a[11] = e("option", { value: "all" }, "All", -1)),
              (n(!0), u($, null, T(x(l).categories, (v) => (n(), u("option", {
                key: v.id,
                value: v.id
              }, c(v.name), 9, _e))), 128))
            ], 512), [
              [S, x(l).categoryFilter]
            ])
          ]),
          e("div", Me, [
            a[14] || (a[14] = e("span", { class: "text-sm text-gray-400" }, "Priority:", -1)),
            w(e("select", {
              "onUpdate:modelValue": a[2] || (a[2] = (v) => x(l).priorityFilter = v),
              class: "px-3 py-1.5 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
            }, [...a[13] || (a[13] = [
              R('<option value="all">All</option><option value="LOW">Low</option><option value="MEDIUM">Medium</option><option value="HIGH">High</option><option value="URGENT">Urgent</option>', 5)
            ])], 512), [
              [S, x(l).priorityFilter]
            ])
          ]),
          e("div", Fe, [
            w(e("input", {
              "onUpdate:modelValue": a[3] || (a[3] = (v) => x(l).searchQuery = v),
              type: "text",
              placeholder: "Search tasks...",
              class: "w-full px-4 py-1.5 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
            }, null, 512), [
              [N, x(l).searchQuery]
            ])
          ]),
          o.value ? (n(), u("button", {
            key: 0,
            onClick: a[4] || (a[4] = (v) => x(l).clearFilters()),
            class: "px-3 py-1.5 text-sm text-gray-400 hover:text-white transition-colors"
          }, " Clear filters ")) : k("", !0)
        ])
      ]),
      x(l).loading ? (n(), u("div", Ue, [...a[15] || (a[15] = [
        e("div", { class: "inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mb-4" }, null, -1),
        e("p", { class: "text-gray-400" }, "Loading tasks...", -1)
      ])])) : x(l).error ? (n(), u("div", Ve, [
        e("div", Re, [
          a[16] || (a[16] = e("svg", {
            class: "w-6 h-6 text-red-400",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            e("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            })
          ], -1)),
          e("p", je, c(x(l).error), 1)
        ])
      ])) : t.value.length > 0 ? (n(), u("div", He, [
        e("div", Ae, [
          e("table", Be, [
            e("thead", Le, [
              e("tr", null, [
                e("th", Pe, [
                  e("input", {
                    type: "checkbox",
                    onChange: L,
                    class: "w-4 h-4 rounded border-gray-600 text-primary-600 focus:ring-primary-500 focus:ring-offset-gray-900"
                  }, null, 32)
                ]),
                a[17] || (a[17] = e("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider" }, " Task ", -1)),
                a[18] || (a[18] = e("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider" }, " Category ", -1)),
                a[19] || (a[19] = e("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider" }, " Priority ", -1)),
                a[20] || (a[20] = e("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider" }, " Status ", -1)),
                a[21] || (a[21] = e("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider" }, " Due Date ", -1)),
                a[22] || (a[22] = e("th", { class: "px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider w-24" }, " Actions ", -1))
              ])
            ]),
            e("tbody", null, [
              (n(!0), u($, null, T(t.value, (v) => (n(), j(de, {
                key: v.id,
                task: v,
                onToggle: s,
                onEdit: m,
                onDelete: A
              }, null, 8, ["task"]))), 128))
            ])
          ])
        ])
      ])) : (n(), u("div", Ge, [
        a[24] || (a[24] = e("svg", {
          class: "w-16 h-16 text-gray-600 mx-auto mb-4",
          fill: "none",
          stroke: "currentColor",
          viewBox: "0 0 24 24"
        }, [
          e("path", {
            "stroke-linecap": "round",
            "stroke-linejoin": "round",
            "stroke-width": "2",
            d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
          })
        ], -1)),
        a[25] || (a[25] = e("h3", { class: "text-xl font-bold text-white mb-2" }, "No tasks found", -1)),
        e("p", We, c(o.value ? "Try adjusting your filters" : "Create your first task to get started"), 1),
        o.value ? k("", !0) : (n(), u("button", {
          key: 0,
          onClick: a[5] || (a[5] = (v) => d.value = !0),
          class: "inline-flex items-center space-x-2 px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-medium transition-colors"
        }, [...a[23] || (a[23] = [
          e("svg", {
            class: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            e("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M12 4v16m8-8H4"
            })
          ], -1),
          e("span", null, "Create First Task", -1)
        ])]))
      ])),
      d.value ? (n(), j(W, {
        key: 4,
        task: y.value,
        categories: x(l).categories,
        onClose: U,
        onSubmit: F
      }, null, 8, ["task", "categories"])) : k("", !0),
      g.value ? (n(), u("div", {
        key: 5,
        class: "fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4",
        onClick: a[7] || (a[7] = P((v) => g.value = !1, ["self"]))
      }, [
        e("div", ze, [
          a[26] || (a[26] = e("h3", { class: "text-xl font-bold text-white mb-4" }, "Delete Task?", -1)),
          a[27] || (a[27] = e("p", { class: "text-gray-300 mb-6" }, " Are you sure you want to delete this task? This action cannot be undone. ", -1)),
          e("div", Qe, [
            e("button", {
              onClick: a[6] || (a[6] = (v) => g.value = !1),
              class: "px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors"
            }, " Cancel "),
            e("button", {
              onClick: B,
              class: "px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
            }, " Delete ")
          ])
        ])
      ])) : k("", !0)
    ]));
  }
}), qe = { class: "space-y-6" }, Je = { class: "flex items-center justify-between" }, Ke = { class: "grid grid-cols-1 md:grid-cols-4 gap-4" }, Xe = { class: "card" }, Ye = { class: "flex items-center justify-between mb-4" }, Ze = { class: "px-2 py-1 bg-gray-700 rounded text-xs text-gray-300" }, et = { class: "space-y-3" }, tt = { class: "font-medium text-white mb-1" }, st = {
  key: 0,
  class: "text-sm text-gray-400 mb-2 line-clamp-2"
}, ot = { class: "flex items-center justify-between" }, rt = { class: "text-xs text-gray-500" }, at = {
  key: 0,
  class: "text-center py-8 text-gray-500 text-sm"
}, lt = { class: "card" }, nt = { class: "flex items-center justify-between mb-4" }, it = { class: "px-2 py-1 bg-gray-700 rounded text-xs text-gray-300" }, ut = { class: "space-y-3" }, dt = { class: "font-medium text-white mb-1" }, ct = {
  key: 0,
  class: "text-sm text-gray-400 mb-2 line-clamp-2"
}, pt = { class: "flex items-center justify-between" }, gt = { class: "text-xs text-gray-500" }, yt = {
  key: 0,
  class: "text-center py-8 text-gray-500 text-sm"
}, mt = { class: "card" }, xt = { class: "flex items-center justify-between mb-4" }, vt = { class: "px-2 py-1 bg-gray-700 rounded text-xs text-gray-300" }, ft = { class: "space-y-3" }, bt = { class: "font-medium text-white mb-1" }, kt = {
  key: 0,
  class: "text-sm text-gray-400 mb-2 line-clamp-2"
}, ht = { class: "flex items-center justify-between" }, wt = { class: "text-xs text-gray-500" }, Dt = {
  key: 0,
  class: "text-center py-8 text-gray-500 text-sm"
}, $t = { class: "card" }, Tt = { class: "flex items-center justify-between mb-4" }, Ct = { class: "px-2 py-1 bg-gray-700 rounded text-xs text-gray-300" }, St = { class: "space-y-3" }, Et = { class: "font-medium text-white mb-1 line-through" }, Nt = {
  key: 0,
  class: "text-sm text-gray-400 mb-2 line-clamp-2"
}, It = { class: "flex items-center justify-between" }, Ot = { class: "text-xs text-gray-500" }, _t = {
  key: 0,
  class: "text-center py-8 text-gray-500 text-sm"
}, Jt = /* @__PURE__ */ I({
  __name: "TaskBoard",
  setup(p) {
    const l = G(), d = h(!1), y = (f) => new Date(f).toLocaleDateString("en-US", { month: "short", day: "numeric" }), g = async (f) => {
      await l.createTask(f), d.value = !1;
    };
    return H(async () => {
      await l.fetchCategories(), await l.fetchTasks();
    }), (f, r) => (n(), u("div", qe, [
      e("div", Je, [
        r[3] || (r[3] = e("h3", { class: "text-2xl font-bold text-white" }, "Task Board", -1)),
        e("button", {
          onClick: r[0] || (r[0] = (t) => d.value = !0),
          class: "flex items-center space-x-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-medium transition-colors"
        }, [...r[2] || (r[2] = [
          e("svg", {
            class: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            e("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M12 4v16m8-8H4"
            })
          ], -1),
          e("span", null, "New Task", -1)
        ])])
      ]),
      e("div", Ke, [
        e("div", Xe, [
          e("div", Ye, [
            r[4] || (r[4] = e("h4", { class: "font-semibold text-white" }, "To Do", -1)),
            e("span", Ze, c(x(l).tasksByStatus.TODO.length), 1)
          ]),
          e("div", et, [
            (n(!0), u($, null, T(x(l).tasksByStatus.TODO, (t) => (n(), u("div", {
              key: t.id,
              class: "p-3 bg-gray-800 rounded-lg border border-gray-700 hover:border-primary-500 transition-colors cursor-pointer"
            }, [
              e("h5", tt, c(t.title), 1),
              t.description ? (n(), u("p", st, c(t.description), 1)) : k("", !0),
              e("div", ot, [
                t.categoryName ? (n(), u("span", {
                  key: 0,
                  class: "text-xs px-2 py-0.5 rounded",
                  style: _({ backgroundColor: t.categoryColor + "20", color: t.categoryColor })
                }, c(t.categoryName), 5)) : k("", !0),
                e("span", rt, c(t.dueDate ? y(t.dueDate) : ""), 1)
              ])
            ]))), 128)),
            x(l).tasksByStatus.TODO.length === 0 ? (n(), u("div", at, " No tasks ")) : k("", !0)
          ])
        ]),
        e("div", lt, [
          e("div", nt, [
            r[5] || (r[5] = e("h4", { class: "font-semibold text-white" }, "In Progress", -1)),
            e("span", it, c(x(l).tasksByStatus.IN_PROGRESS.length), 1)
          ]),
          e("div", ut, [
            (n(!0), u($, null, T(x(l).tasksByStatus.IN_PROGRESS, (t) => (n(), u("div", {
              key: t.id,
              class: "p-3 bg-gray-800 rounded-lg border border-gray-700 hover:border-blue-500 transition-colors cursor-pointer"
            }, [
              e("h5", dt, c(t.title), 1),
              t.description ? (n(), u("p", ct, c(t.description), 1)) : k("", !0),
              e("div", pt, [
                t.categoryName ? (n(), u("span", {
                  key: 0,
                  class: "text-xs px-2 py-0.5 rounded",
                  style: _({ backgroundColor: t.categoryColor + "20", color: t.categoryColor })
                }, c(t.categoryName), 5)) : k("", !0),
                e("span", gt, c(t.dueDate ? y(t.dueDate) : ""), 1)
              ])
            ]))), 128)),
            x(l).tasksByStatus.IN_PROGRESS.length === 0 ? (n(), u("div", yt, " No tasks ")) : k("", !0)
          ])
        ]),
        e("div", mt, [
          e("div", xt, [
            r[6] || (r[6] = e("h4", { class: "font-semibold text-white" }, "In Review", -1)),
            e("span", vt, c(x(l).tasksByStatus.IN_REVIEW.length), 1)
          ]),
          e("div", ft, [
            (n(!0), u($, null, T(x(l).tasksByStatus.IN_REVIEW, (t) => (n(), u("div", {
              key: t.id,
              class: "p-3 bg-gray-800 rounded-lg border border-gray-700 hover:border-purple-500 transition-colors cursor-pointer"
            }, [
              e("h5", bt, c(t.title), 1),
              t.description ? (n(), u("p", kt, c(t.description), 1)) : k("", !0),
              e("div", ht, [
                t.categoryName ? (n(), u("span", {
                  key: 0,
                  class: "text-xs px-2 py-0.5 rounded",
                  style: _({ backgroundColor: t.categoryColor + "20", color: t.categoryColor })
                }, c(t.categoryName), 5)) : k("", !0),
                e("span", wt, c(t.dueDate ? y(t.dueDate) : ""), 1)
              ])
            ]))), 128)),
            x(l).tasksByStatus.IN_REVIEW.length === 0 ? (n(), u("div", Dt, " No tasks ")) : k("", !0)
          ])
        ]),
        e("div", $t, [
          e("div", Tt, [
            r[7] || (r[7] = e("h4", { class: "font-semibold text-white" }, "Done", -1)),
            e("span", Ct, c(x(l).tasksByStatus.DONE.length), 1)
          ]),
          e("div", St, [
            (n(!0), u($, null, T(x(l).tasksByStatus.DONE, (t) => (n(), u("div", {
              key: t.id,
              class: "p-3 bg-gray-800 rounded-lg border border-gray-700 hover:border-green-500 transition-colors cursor-pointer opacity-75"
            }, [
              e("h5", Et, c(t.title), 1),
              t.description ? (n(), u("p", Nt, c(t.description), 1)) : k("", !0),
              e("div", It, [
                t.categoryName ? (n(), u("span", {
                  key: 0,
                  class: "text-xs px-2 py-0.5 rounded",
                  style: _({ backgroundColor: t.categoryColor + "20", color: t.categoryColor })
                }, c(t.categoryName), 5)) : k("", !0),
                e("span", Ot, c(t.completedAt ? y(t.completedAt) : ""), 1)
              ])
            ]))), 128)),
            x(l).tasksByStatus.DONE.length === 0 ? (n(), u("div", _t, " No tasks ")) : k("", !0)
          ])
        ])
      ]),
      d.value ? (n(), j(W, {
        key: 0,
        categories: x(l).categories,
        onClose: r[1] || (r[1] = (t) => d.value = !1),
        onSubmit: g
      }, null, 8, ["categories"])) : k("", !0)
    ]));
  }
}), Mt = { class: "space-y-6" }, Ft = { class: "flex items-center justify-between" }, Ut = { class: "card" }, Vt = { class: "border-t border-gray-700 pt-6" }, Rt = { class: "space-y-3" }, jt = { class: "flex-1" }, Ht = { class: "font-medium text-white" }, At = { class: "text-sm text-gray-400" }, Bt = { class: "text-right" }, Lt = { class: "text-sm font-medium text-white" }, Pt = {
  key: 0,
  class: "text-center py-8 text-gray-500"
}, Kt = /* @__PURE__ */ I({
  __name: "TaskCalendar",
  setup(p) {
    const l = G(), d = h(!1), y = E(() => l.tasks.filter((t) => t.dueDate && !t.isArchived && t.status !== "DONE").sort((t, o) => new Date(t.dueDate).getTime() - new Date(o.dueDate).getTime()).slice(0, 10)), g = (t) => {
      const o = new Date(t), s = /* @__PURE__ */ new Date(), m = new Date(s);
      return m.setDate(m.getDate() + 1), o.toDateString() === s.toDateString() ? "Today" : o.toDateString() === m.toDateString() ? "Tomorrow" : o.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
    }, f = (t) => {
      const o = {
        LOW: "bg-blue-500/20 text-blue-400",
        MEDIUM: "bg-yellow-500/20 text-yellow-400",
        HIGH: "bg-orange-500/20 text-orange-400",
        URGENT: "bg-red-500/20 text-red-400"
      };
      return o[t] || o.MEDIUM;
    }, r = async (t) => {
      await l.createTask(t), d.value = !1;
    };
    return H(async () => {
      await l.fetchCategories(), await l.fetchTasks();
    }), (t, o) => (n(), u("div", Mt, [
      e("div", Ft, [
        o[3] || (o[3] = e("h3", { class: "text-2xl font-bold text-white" }, "Task Calendar", -1)),
        e("button", {
          onClick: o[0] || (o[0] = (s) => d.value = !0),
          class: "flex items-center space-x-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-medium transition-colors"
        }, [...o[2] || (o[2] = [
          e("svg", {
            class: "w-5 h-5",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24"
          }, [
            e("path", {
              "stroke-linecap": "round",
              "stroke-linejoin": "round",
              "stroke-width": "2",
              d: "M12 4v16m8-8H4"
            })
          ], -1),
          e("span", null, "New Task", -1)
        ])])
      ]),
      e("div", Ut, [
        o[5] || (o[5] = R('<div class="text-center py-12"><svg class="w-16 h-16 text-gray-600 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg><h4 class="text-lg font-semibold text-white mb-2">Calendar View</h4><p class="text-gray-400 mb-6">Full calendar view coming soon</p></div>', 1)),
        e("div", Vt, [
          o[4] || (o[4] = e("h4", { class: "font-semibold text-white mb-4" }, "Upcoming Tasks", -1)),
          e("div", Rt, [
            (n(!0), u($, null, T(y.value, (s) => (n(), u("div", {
              key: s.id,
              class: "flex items-center justify-between p-3 bg-gray-800 rounded-lg"
            }, [
              e("div", jt, [
                e("h5", Ht, c(s.title), 1),
                e("p", At, c(s.categoryName || "No category"), 1)
              ]),
              e("div", Bt, [
                e("p", Lt, c(g(s.dueDate)), 1),
                e("span", {
                  class: M(["inline-block px-2 py-0.5 rounded text-xs", f(s.priority)])
                }, c(s.priority), 3)
              ])
            ]))), 128)),
            y.value.length === 0 ? (n(), u("div", Pt, " No upcoming tasks ")) : k("", !0)
          ])
        ])
      ]),
      d.value ? (n(), j(W, {
        key: 0,
        categories: x(l).categories,
        onClose: o[1] || (o[1] = (s) => d.value = !1),
        onSubmit: r
      }, null, 8, ["categories"])) : k("", !0)
    ]));
  }
}), Xt = {
  name: "Task Manager",
  version: "1.0.0",
  author: "NJO Team"
};
console.log("📋 Task Manager Plugin loaded");
export {
  Jt as TaskBoard,
  Kt as TaskCalendar,
  de as TaskCard,
  Qt as TaskFilters,
  W as TaskForm,
  qt as TaskList,
  Xt as pluginInfo,
  G as useTaskStore
};
